
CREATE TABLE Students (Student_ID serial 
PRIMARY KEY, first_name varchar (50) NOT NULL, 
			 last_name varchar (50) NOT NULL,
			 Email varchar (100) UNIQUE NOT NULL);

CREATE TABLE professors (professor_ID bigserial
PRIMARY KEY, first_name varchar (50) NOT NULL, 
			 last_name varchar (50) NOT NULL,
			 email varchar (100) UNIQUE NOT NULL);

CREATE TABLE courses (course_id serial
PRIMARY KEY, courseName varchar (100) NOT NULL, 
			 creditHours int NOT NULL,
			 department varchar (100) NOT NULL,
			 professor_id int 
			 REFERENCES professors(professor_id));

CREATE TABLE registrations (registration_id serial 
PRIMARY KEY, student_id int 
			 REFERENCES students(student_ID),
			 course_id int 
			 REFERENCES courses(course_id),
			 registration_date timestamp DEFAULT CURRENT_TIMESTAMP);

