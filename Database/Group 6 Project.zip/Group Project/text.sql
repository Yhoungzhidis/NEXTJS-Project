create database retail_store;

CREATE TABLE Customers (
    Customer_ID SERIAL PRIMARY KEY,
    Customer_Name VARCHAR(100) NOT NULL,
    Address VARCHAR(255) NOT NULL,
	Phone_number VARCHAR(15),
	Email VARCHAR(255)
);

CREATE TABLE Products (
    Product_ID SERIAL PRIMARY KEY,
    Product_Name VARCHAR(100) NOT NULL,
    Price DECIMAL(10, 2) NOT NULL CHECK (Price > 0),
	Manufacturer VARCHAR(100) NOT NULL
);
Alter table Products
Add constraint manufacturers
unique (Manufacturer)

CREATE TABLE Orders (
    Order_ID SERIAL PRIMARY KEY,
    Customer_ID INT NOT NULL REFERENCES Customers(Customer_ID),
    OrderDate DATE NOT NULL,
	OrderTime TIME NOT NULL
);

CREATE TABLE OrderDetails (
    Order_ID INT NOT NULL REFERENCES Orders(Order_ID),
    Product_ID INT NOT NULL REFERENCES Products(Product_ID),
    Quantity INT NOT NULL CHECK (Quantity > 0),
	Manufacturer VARCHAR(255),
	Tracking_ID VARCHAR(255) NOT NULL
    
);

CREATE TABLE Shipping (
    Order_ID INT PRIMARY KEY REFERENCES Orders(Order_ID),
    ShippingDate DATE NOT NULL,
    Address VARCHAR(255) NOT NULL,
	Tracking_ID VARCHAR(255) NOT NULL
);

Alter table Shipping
Add constraint trackingID
unique (Tracking_ID);

Alter table OrderDetails
Add constraint fk_order
foreign key (order_ID)
references orders(Order_ID);

Alter table OrderDetails
Add constraint fk_product
foreign key (product_ID)
references products(product_ID);

Alter table OrderDetails
Add constraint fk_order
foreign key (tracking_ID)
references shipping(tracking_ID);